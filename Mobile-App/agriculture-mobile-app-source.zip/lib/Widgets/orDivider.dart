import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class OrDivider extends StatelessWidget {
  final String label;

  const OrDivider({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      const Expanded(child: Divider(color: AppColors.divider, thickness: 1)),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Text(label,
            style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.textMuted)),
      ),
      const Expanded(child: Divider(color: AppColors.divider, thickness: 1)),
    ]);
  }
}