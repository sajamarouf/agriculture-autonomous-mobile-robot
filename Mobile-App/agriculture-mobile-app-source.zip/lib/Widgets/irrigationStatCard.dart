import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class IrrigationStatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const IrrigationStatCard({
    super.key,
    required this.label,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: GoogleFonts.dmSans(
                  fontSize: 12, color: AppColors.textMuted)),
          const SizedBox(height: 6),
          Text(value,
              style: GoogleFonts.dmSans(
                  fontSize: 28,
                  fontWeight: FontWeight.w500,
                  color: valueColor ?? const Color(0xFF185FA5))),
        ],
      ),
    );
  }
}