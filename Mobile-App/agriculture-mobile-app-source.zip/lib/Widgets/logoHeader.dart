import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class LogoHeader extends StatelessWidget {
  final String imagePath;
  final String appName;
  final String tagline;

  const LogoHeader({
    super.key,
    required this.imagePath,
    required this.appName,
    required this.tagline,
  });

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Image.asset(imagePath, width: 80, height: 80, fit: BoxFit.cover),
        ),
      ),
      const SizedBox(height: 10),
      Text(appName,
          textAlign: TextAlign.center,
          style: GoogleFonts.fraunces(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: AppColors.textDark,
              letterSpacing: -0.3)),
      const SizedBox(height: 2),
      Text(tagline,
          textAlign: TextAlign.center,
          style: GoogleFonts.dmSans(
              fontSize: 11,
              color: AppColors.textMuted,
              letterSpacing: 0.5)),
    ]);
  }
}