import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/TankProgressRow.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class RobotTelemetryCard extends StatelessWidget {
  final String currentMode;       
  final String location;         
  final double batteryLevel;     
  final double waterTankLevel;    
  final String? lastSeen;         

  const RobotTelemetryCard({
    super.key,
    required this.currentMode,
    required this.location,
    required this.batteryLevel,
    required this.waterTankLevel,
    this.lastSeen,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Card header ─────────────────────────────────────────────────
          Row(children: [
            const Icon(Icons.memory_outlined,
                size: 16, color: AppColors.textMuted),
            const SizedBox(width: 7),
            Text('Robot Telemetry',
                style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textDark)),
          ]),
          const SizedBox(height: 14),

          // ── Mode + Location ──────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Current Mode',
                    style: GoogleFonts.dmSans(
                        fontSize: 11, color: AppColors.textMuted)),
                const SizedBox(height: 4),
                _ModeBadge(label: currentMode),
              ]),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('Location',
                    style: GoogleFonts.dmSans(
                        fontSize: 11, color: AppColors.textMuted)),
                const SizedBox(height: 4),
                Row(children: [
                  const Icon(Icons.location_on_outlined,
                      size: 13, color: AppColors.textMuted),
                  const SizedBox(width: 3),
                  Text(location,
                      style: GoogleFonts.dmSans(
                          fontSize: 13, color: AppColors.textDark)),
                ]),
              ]),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppColors.border, thickness: 0.5, height: 1),
          const SizedBox(height: 14),

          // ── Battery ──────────────────────────────────────────────────────
          TankProgressRow(
            icon: Icons.battery_charging_full_outlined,
            label: 'Battery',
            value: batteryLevel,
            barColor: AppColors.primary,
          ),
          const SizedBox(height: 14),
          const Divider(color: AppColors.border, thickness: 0.5, height: 1),
          const SizedBox(height: 14),

          // ── Water Tank ───────────────────────────────────────────────────
          TankProgressRow(
            icon: Icons.water_drop_outlined,
            label: 'Water Tank',
            value: waterTankLevel,
            barColor: AppColors.primary,
            lastSeen: lastSeen,
          ),
        ],
      ),
    );
  }
}

class _ModeBadge extends StatelessWidget {
  final String label;
  const _ModeBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.tabBg,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Text(label,
          style: GoogleFonts.dmSans(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppColors.textDark)),
    );
  }
}

// ─── Example usage in your dashboard screen ──────────────────────────────────
//
// RobotTelemetryCard(
//   currentMode: 'Monitoring',
//   location: 'Zone A - Tomatoes',
//   batteryLevel: 0.78,
//   waterTankLevel: 0.65,
//   lastSeen: '23:48:44 PM',
// )