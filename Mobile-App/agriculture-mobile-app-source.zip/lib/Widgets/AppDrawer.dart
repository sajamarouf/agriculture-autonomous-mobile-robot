import 'package:abed_gp2/Widgets/navItemData.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class AppDrawer extends StatelessWidget {
  final String appName;

  final IconData headerIcon;

  final List<NavItemData> items;

  final String activeRoute;

  final ValueChanged<NavItemData> onItemTap;

  const AppDrawer({
    super.key,
    required this.appName,
    required this.headerIcon,
    required this.items,
    required this.activeRoute,
    required this.onItemTap,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFFEAF3DE), // green-50 from AppColors palette
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            _DrawerHeader(appName: appName, icon: headerIcon),

            const Divider(color: Color(0xFFC0DD97), thickness: 0.5, height: 1),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                child: Column(
                  children: items.map((item) => _NavItem(
                    data: item,
                    isActive: item.routeName == activeRoute,
                    onTap: () {
                      Navigator.of(context).pop(); // close drawer
                      onItemTap(item);
                    },
                  )).toList(),
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  final String appName;
  final IconData icon;

  const _DrawerHeader({required this.appName, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 14),
      child: Row(children: [
        Icon(icon, size: 20, color: const Color(0xFF3B6D11)),
        const SizedBox(width: 9),
        Text(
          appName,
          style: GoogleFonts.fraunces(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF27500A),
          ),
        ),
      ]),
    );
  }
}

class _NavItem extends StatelessWidget {
  final NavItemData data;
  final bool isActive;
  final VoidCallback onTap;

  const _NavItem({
    required this.data,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(bottom: 2),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFC0DD97) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(children: [
          Icon(
            data.icon,
            size: 18,
            color: isActive
                ? const Color(0xFF27500A)
                : const Color(0xFF3B6D11),
          ),
          const SizedBox(width: 10),
          Text(
            data.label,
            style: GoogleFonts.dmSans(
              fontSize: 14,
              fontWeight: isActive ? FontWeight.w500 : FontWeight.w400,
              color: isActive
                  ? const Color(0xFF27500A)
                  : const Color(0xFF3B6D11),
            ),
          ),
        ]),
      ),
    );
  }
}