import 'package:flutter/material.dart';

class AppColors {
  static const background  = Color(0xFFF7FAF5);
  static const cardWhite   = Color(0xFFFFFFFF);
  static const primary     = Color(0xFF2D9E3A);
  static const primaryDark = Color(0xFF1A7A28);
  static const border      = Color(0xFFCDE8C4);
  static const borderFocus = Color(0xFF3A9E4A);
  static const textDark    = Color(0xFF1A4D21);
  static const textMid     = Color(0xFF4A7D50);
  static const textMuted   = Color(0xFF7AAA7E);
  static const textHint    = Color(0xFFB5D8B8);
  static const tabBg       = Color(0xFFE4F2E0);
  static const divider     = Color(0xFFDAEEDA);
  static const iconColor   = Color(0xFF8DC890);
}