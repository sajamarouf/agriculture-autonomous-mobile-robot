import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color? iconColor;
  final Color? valueColor;
  final String? subtitle;
  final Color? subtitleColor;
  
  final double? progress;
  final Color? progressColor;

  const StatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.iconColor,
    this.valueColor,
    this.subtitle,
    this.subtitleColor,
    this.progress,
    this.progressColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Top row: title + icon ─────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.dmSans(
                      fontSize: 12, color: AppColors.textMuted),
                  maxLines: 2,
                ),
              ),
              const SizedBox(width: 6),
              Icon(icon,
                  size: 18,
                  color: iconColor ?? AppColors.textMuted),
            ],
          ),
          const SizedBox(height: 8),

          // ── Value ─────────────────────────────────────────────────────────
          Text(
            value,
            style: GoogleFonts.dmSans(
              fontSize: 26,
              fontWeight: FontWeight.w500,
              color: valueColor ?? AppColors.textDark,
              height: 1.1,
            ),
          ),

          // ── Optional progress bar ─────────────────────────────────────────
          if (progress != null) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                value: progress!.clamp(0.0, 1.0),
                minHeight: 5,
                backgroundColor: AppColors.border,
                valueColor: AlwaysStoppedAnimation<Color>(
                    progressColor ?? AppColors.primary),
              ),
            ),
          ],

          // ── Optional subtitle ─────────────────────────────────────────────
          if (subtitle != null) ...[
            const SizedBox(height: 6),
            Text(
              subtitle!,
              style: GoogleFonts.dmSans(
                fontSize: 11,
                color: subtitleColor ?? AppColors.textMuted,
              ),
            ),
          ],
        ],
      ),
    );
  }
}