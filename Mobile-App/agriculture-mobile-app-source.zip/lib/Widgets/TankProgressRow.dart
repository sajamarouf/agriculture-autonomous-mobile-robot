import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// A single labeled progress row (e.g. Water Tank 65%, Battery 78%)
class TankProgressRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final double value;          
  final Color? barColor;
  final String? lastSeen;      

  const TankProgressRow({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
    this.barColor,
    this.lastSeen,
  });

  String get _percentage => '${(value * 100).round()}%';

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Label row ──────────────────────────────────────────────────────
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(children: [
              Icon(icon, size: 16, color: AppColors.textMuted),
              const SizedBox(width: 6),
              Text(label,
                  style: GoogleFonts.dmSans(
                      fontSize: 13, color: AppColors.textMuted)),
            ]),
            Text(_percentage,
                style: GoogleFonts.dmSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textDark)),
          ],
        ),
        const SizedBox(height: 7),

        // ── Progress bar ───────────────────────────────────────────────────
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: value.clamp(0.0, 1.0),
            minHeight: 6,
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation<Color>(
                barColor ?? AppColors.primary),
          ),
        ),

        // ── Last seen timestamp ────────────────────────────────────────────
        if (lastSeen != null) ...[
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              'Last seen: $lastSeen',
              style: GoogleFonts.dmSans(
                  fontSize: 11,
                  color: AppColors.textMuted.withOpacity(0.7)),
            ),
          ),
        ],
      ],
    );
  }
}