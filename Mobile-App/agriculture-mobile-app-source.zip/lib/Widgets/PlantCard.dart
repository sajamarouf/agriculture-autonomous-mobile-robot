import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/plantStatus.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PlantCardData {
  final String name;
  final String species;
  final String zone;
  final String fruit;
  final PlantStatus status;

  const PlantCardData({
    required this.name,
    required this.species,
    required this.zone,
    required this.fruit,
    required this.status,
  });
}

class PlantCard extends StatelessWidget {
  final PlantCardData data;
  final VoidCallback? onTap;

  const PlantCard({super.key, required this.data, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.cardWhite,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border, width: 0.5),
        ),
        clipBehavior: Clip.hardEdge,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Stack(
              children: [
                Container(
                  height: 90,
                  width: double.infinity,
                  color: const Color(0xFFEAF3DE),
                  child: const Center(
                    child: Icon(Icons.eco_outlined,
                        size: 32, color: Color(0xFFC0DD97)),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: _StatusBadge(status: data.status),
                ),
              ],
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data.name,
                      style: GoogleFonts.dmSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textDark),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(data.species,
                      style: GoogleFonts.dmSans(
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                          color: AppColors.textMuted),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Row(children: [
                    const Icon(Icons.circle,
                        size: 7, color: Color(0xFF3B6D11)),
                    const SizedBox(width: 5),
                    Text(data.zone,
                        style: GoogleFonts.dmSans(
                            fontSize: 11, color: AppColors.textMuted)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final PlantStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: status.badgeBackground,
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(status.label,
          style: GoogleFonts.dmSans(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: status.badgeText)),
    );
  }
}