import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TabToggle extends StatelessWidget {
  final int activeIndex;
  final List<String> labels;
  final ValueChanged<int> onTap;

  const TabToggle({
    super.key,
    required this.activeIndex,
    required this.labels,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
          color: AppColors.tabBg, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: List.generate(labels.length, (i) => Expanded(
          child: GestureDetector(
            onTap: () => onTap(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: activeIndex == i ? AppColors.cardWhite : Colors.transparent,
                borderRadius: BorderRadius.circular(9),
                boxShadow: activeIndex == i
                    ? [BoxShadow(
                        color: AppColors.primary.withOpacity(0.15),
                        blurRadius: 6,
                        offset: const Offset(0, 1))]
                    : null,
              ),
              alignment: Alignment.center,
              child: Text(labels[i],
                  style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: activeIndex == i
                          ? AppColors.textDark
                          : AppColors.textMuted)),
            ),
          ),
        )),
      ),
    );
  }
}