import 'package:abed_gp2/Routes/route1_string.dart';
import 'package:flutter/material.dart';

class NavItemData {
  final String label;
  final IconData icon;
  final String routeName; 

  const NavItemData({
    required this.label,
    required this.icon,
    required this.routeName,
  });
}

const List<NavItemData> appNavItems = [
  NavItemData(
    label: 'Dashboard',
    icon: Icons.grid_view_rounded,
    routeName: Route1String.dashboardScreen,
  ),
  NavItemData(
    label: 'Plants',
    icon: Icons.eco_outlined,
    routeName: Route1String.plantsScreen,
  ),
  NavItemData(
    label: 'Irrigation',
    icon: Icons.water_drop_outlined,
    routeName: Route1String.irrigationScreen,
  ),
  NavItemData(
    label: 'Alerts',
    icon: Icons.warning_amber_outlined,
    routeName: Route1String.alertsScreen,
  ),
];