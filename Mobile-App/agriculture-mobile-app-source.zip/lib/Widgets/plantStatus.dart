import 'package:flutter/material.dart';

enum PlantStatus { healthy, diseased, stressed, underwatered, overwatered }

extension PlantStatusExt on PlantStatus {
  String get label {
    switch (this) {
      case PlantStatus.healthy:
        return 'Healthy';
      case PlantStatus.diseased:
        return 'Diseased';
      case PlantStatus.stressed:
        return 'Stressed';
      case PlantStatus.underwatered:
        return 'Underwatered';
      case PlantStatus.overwatered:
        return 'Overwatered';
    }
  }

  Color get badgeBackground {
    switch (this) {
      case PlantStatus.healthy:
        return const Color(0xFF3B6D11);
      case PlantStatus.diseased:
        return const Color(0xFFE24B4A);
      case PlantStatus.stressed:
        return const Color(0xFFBA7517);
      case PlantStatus.underwatered:
        return const Color(0xFFE24B4A);
      case PlantStatus.overwatered:
        return const Color(0xFF185FA5);
    }
  }

  Color get badgeText {
    switch (this) {
      case PlantStatus.healthy:
        return const Color(0xFFEAF3DE);
      case PlantStatus.diseased:
        return const Color(0xFFFCEBEB);
      case PlantStatus.stressed:
        return const Color(0xFFFAEEDA);
      case PlantStatus.underwatered:
        return const Color(0xFFFCEBEB);
      case PlantStatus.overwatered:
        return const Color(0xFFE6F1FB);
    }
  }
}
