import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class BottomLink extends StatelessWidget {
  final String prefix;
  final String action;
  final VoidCallback? onTap;

  const BottomLink({
    super.key,
    required this.prefix,
    required this.action,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: RichText(
        textAlign: TextAlign.center,
        text: TextSpan(
          style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.textMuted),
          children: [
            TextSpan(text: prefix),
            TextSpan(
                text: action,
                style: const TextStyle(
                    color: AppColors.primary, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}