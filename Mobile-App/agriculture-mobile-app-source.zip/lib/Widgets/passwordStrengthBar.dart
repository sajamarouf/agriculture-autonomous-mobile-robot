import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


enum PasswordStrength { none, weak, good, strong }

extension PasswordStrengthExt on PasswordStrength {
  int get filledSegments {
    switch (this) {
      case PasswordStrength.none:   return 0;
      case PasswordStrength.weak:   return 1;
      case PasswordStrength.good:   return 3;
      case PasswordStrength.strong: return 4;
    }
  }

  Color get color {
    switch (this) {
      case PasswordStrength.none:   return AppColors.divider;
      case PasswordStrength.weak:   return Colors.redAccent;
      case PasswordStrength.good:   return const Color(0xFF3A9E4A);
      case PasswordStrength.strong: return const Color(0xFF1A7A28);
    }
  }

  String get label {
    switch (this) {
      case PasswordStrength.none:   return '';
      case PasswordStrength.weak:   return 'Weak';
      case PasswordStrength.good:   return 'Good strength';
      case PasswordStrength.strong: return 'Strong';
    }
  }

  static PasswordStrength fromPassword(String password) {
    if (password.isEmpty)    return PasswordStrength.none;
    if (password.length < 6) return PasswordStrength.weak;
    final hasUpper   = password.contains(RegExp(r'[A-Z]'));
    final hasDigit   = password.contains(RegExp(r'[0-9]'));
    final hasSpecial = password.contains(RegExp(r'[!@#\$&*~]'));
    final score = (hasUpper ? 1 : 0) + (hasDigit ? 1 : 0) + (hasSpecial ? 1 : 0);
    if (score == 3) return PasswordStrength.strong;
    if (score >= 1) return PasswordStrength.good;
    return PasswordStrength.weak;
  }
}

class PasswordStrengthBar extends StatelessWidget {
  final PasswordStrength strength;

  const PasswordStrengthBar({super.key, required this.strength});

  @override
  Widget build(BuildContext context) {
    const total  = 4;
    final filled = strength.filledSegments;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(
        children: List.generate(total, (i) => Expanded(
          child: Container(
            margin: EdgeInsets.only(right: i < total - 1 ? 4 : 0),
            height: 4,
            decoration: BoxDecoration(
              color: i < filled ? strength.color : AppColors.divider,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        )),
      ),
      if (strength.label.isNotEmpty) ...[
        const SizedBox(height: 4),
        Text(strength.label,
            style: GoogleFonts.dmSans(fontSize: 11, color: strength.color)),
      ],
    ]);
  }
}