import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AlertItemData {
  final String type;       
  final String? zoneTag;    
  final String description;
  final String timestamp;   

  const AlertItemData({
    required this.type,
    this.zoneTag,
    required this.description,
    required this.timestamp,
  });
}

class AlertItem extends StatelessWidget {
  final AlertItemData data;

  const AlertItem({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Container(
            width: 22,
            height: 22,
            margin: const EdgeInsets.only(top: 1),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.primary, width: 1.5),
            ),
            child: const Icon(Icons.check_rounded,
                size: 13, color: AppColors.primary),
          ),
          const SizedBox(width: 10),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 6,
                  children: [
                    Text(data.type,
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: AppColors.textDark,
                            letterSpacing: 0.3)),
                    if (data.zoneTag != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(data.zoneTag!,
                            style: GoogleFonts.dmSans(
                                fontSize: 10,
                                color: AppColors.textMuted)),
                      ),
                  ],
                ),
                const SizedBox(height: 3),

               
                Text(data.description,
                    style: GoogleFonts.dmSans(
                        fontSize: 12, color: AppColors.textMuted)),
                const SizedBox(height: 5),

              
                Row(children: [
                  const Icon(Icons.access_time_rounded,
                      size: 11, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text(data.timestamp,
                      style: GoogleFonts.dmSans(
                          fontSize: 11, color: AppColors.textMuted)),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}