import 'package:abed_gp2/Widgets/statCard.dart';
import 'package:flutter/material.dart';


class StatCardData {
  final String title;
  final String value;
  final IconData icon;
  final Color? iconColor;
  final Color? valueColor;
  final String? subtitle;
  final Color? subtitleColor;
  final double? progress;     
  final Color? progressColor;

  const StatCardData({
    required this.title,
    required this.value,
    required this.icon,
    this.iconColor,
    this.valueColor,
    this.subtitle,
    this.subtitleColor,
    this.progress,
    this.progressColor,
  });
}

class StatCardsRow extends StatelessWidget {
  final List<StatCardData> cards;

  const StatCardsRow({super.key, required this.cards});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.5,
      children: cards
          .map((data) => StatCard(
                title: data.title,
                value: data.value,
                icon: data.icon,
                iconColor: data.iconColor,
                valueColor: data.valueColor,
                subtitle: data.subtitle,
                subtitleColor: data.subtitleColor,
                progress: data.progress,
                progressColor: data.progressColor,
              ))
          .toList(),
    );
  }
}

