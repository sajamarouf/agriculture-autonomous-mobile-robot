import 'package:abed_gp2/Pages/alertsScreen.dart';
import 'package:abed_gp2/Pages/dashboardScreen.dart';
import 'package:abed_gp2/Pages/irrigationScreen.dart';
import 'package:abed_gp2/Pages/plantsScreen.dart';
import 'package:abed_gp2/Pages/signinScreen.dart';
import 'package:abed_gp2/Pages/signupScreen.dart';
import 'package:abed_gp2/Routes/route1_string.dart';
import 'package:flutter/material.dart';

class Route1 {
Map<String,Widget Function(BuildContext)> route1={

  Route1String.signInScreen:(context) => const SignInScreen(),
    Route1String.signUpScreen:(context) => const SignUpScreen(),
    Route1String.dashboardScreen:(context) => const DashboardScreen(),
    Route1String.plantsScreen:(context) => const PlantsScreen(),
    Route1String.irrigationScreen:(context) => const IrrigationScreen(),
    Route1String.alertsScreen:(context) => const AlertsScreen(),

};


}
