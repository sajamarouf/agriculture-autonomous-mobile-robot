class Route1String {
  static const String welcomePage = '/';
  static const String splashScreen = '/splashScreenPage';

  static const String signInScreen = '/signInScreen';
  static const String signUpScreen = '/signUpScreen';

  static const String dashboardScreen = '/dashboard';
  static const String plantsScreen = '/plants';
  static const String irrigationScreen = '/irrigation';
  static const String alertsScreen = '/alertScreen';
}