import 'dart:convert';
import 'package:http/http.dart' as http;

class RaspberryScanResult {
  final bool ready;
  final bool locked;
  final String type;
  final String fruit;
  final String disease;
  final double confidence;
  final String info;

  const RaspberryScanResult({
    required this.ready,
    required this.locked,
    required this.type,
    required this.fruit,
    required this.disease,
    required this.confidence,
    required this.info,
  });

  factory RaspberryScanResult.fromJson(Map<String, dynamic> json) {
    return RaspberryScanResult(
      ready: json['ready'] == true,
      locked: json['locked'] == true,
      type: (json['type'] ?? '').toString(),
      fruit: (json['fruit'] ?? '').toString().toLowerCase().trim(),
      disease: (json['disease'] ?? '').toString().trim(),
      confidence: _toDouble(json['confidence']),
      info: (json['info'] ?? '').toString(),
    );
  }

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }
}

class RaspberryApi {
  // غيّر هذا الـ IP إذا تغير IP الرازبيري عندك.
  static const String baseUrl = 'http://172.20.10.2:8000';

  static Future<RaspberryScanResult> getResult() async {
    final response = await http
        .get(Uri.parse('$baseUrl/result'))
        .timeout(const Duration(seconds: 8));

    if (response.statusCode != 200) {
      throw Exception('Failed to get Raspberry result: ${response.statusCode}');
    }

    final Map<String, dynamic> data = jsonDecode(response.body);
    return RaspberryScanResult.fromJson(data);
  }

  static Future<void> resetScan() async {
    await http
        .get(Uri.parse('$baseUrl/reset'))
        .timeout(const Duration(seconds: 8));
  }
}
