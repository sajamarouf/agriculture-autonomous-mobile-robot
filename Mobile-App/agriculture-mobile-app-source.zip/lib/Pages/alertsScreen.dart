import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/AppDrawer.dart';
import 'package:abed_gp2/Widgets/alertItem.dart';
import 'package:abed_gp2/Widgets/filterTabBar.dart';
import 'package:abed_gp2/Widgets/navItemData.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  int _filterIndex = 0; // 0=Active, 1=Resolved, 2=All
  final List<String> _filterTabs = ['Active', 'Resolved', 'All'];

  static const List<AlertItemData> _allAlerts = [
    AlertItemData(
      type: 'OVERWATERING',
      zoneTag: 'Zone C – Herbs',
      description: 'Zone C moisture above 75% – irrigation paused',
      timestamp: 'Apr 8, 11:49',
    ),
    AlertItemData(
      type: 'OBSTACLE DETECTED',
      zoneTag: 'Zone A – Tomatoes',
      description: 'Obstacle detected near Zone A – robot rerouted',
      timestamp: 'Apr 7, 23:49',
    ),
    AlertItemData(
      type: 'LOW BATTERY',
      description: 'Robot battery at 15% – returning to charging station',
      timestamp: 'Apr 7, 11:49',
    ),
  ];

  List<AlertItemData> get _visibleAlerts => _allAlerts;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      drawer: AppDrawer(
        appName: 'AgriBot OS',
        headerIcon: Icons.smart_toy_outlined,
        items: appNavItems,
        activeRoute: '/alerts',
        onItemTap: (item) => Navigator.pushReplacementNamed(context, item.routeName),
      ),
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: AppColors.textDark),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: Text('System Alerts',
            style: GoogleFonts.fraunces(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: AppColors.textDark)),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Robot and field monitoring notifications',
                style: GoogleFonts.dmSans(
                    fontSize: 12, color: AppColors.textMuted)),
            const SizedBox(height: 14),

            FilterTabBar(
              tabs: _filterTabs,
              activeIndex: _filterIndex,
              onTap: (i) => setState(() => _filterIndex = i),
            ),
            const SizedBox(height: 14),

            Expanded(
              child: ListView(
                children: _visibleAlerts
                    .map((alert) => AlertItem(data: alert))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}