import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/AppDrawer.dart';
import 'package:abed_gp2/Widgets/irrigationStatCard.dart';
import 'package:abed_gp2/Widgets/navItemData.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class IrrigationScreen extends StatelessWidget {
  const IrrigationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      drawer: AppDrawer(
        appName: 'AgriBot OS',
        headerIcon: Icons.smart_toy_outlined,
        items: appNavItems,
        activeRoute: '/irrigation',
        onItemTap: (item) => Navigator.pushReplacementNamed(context, item.routeName),
      ),
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: AppColors.textDark),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: Text('Irrigation Log',
            style: GoogleFonts.fraunces(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: AppColors.textDark)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Water usage and event history',
                style: GoogleFonts.dmSans(
                    fontSize: 12, color: AppColors.textMuted)),
            const SizedBox(height: 16),

            IrrigationStatCard(
              label: 'Total Water Used',
              value: '11.4L',
              valueColor: const Color(0xFF185FA5),
            ),
            const SizedBox(height: 12),

            
          ],
        ),
      ),
    );
  }
}