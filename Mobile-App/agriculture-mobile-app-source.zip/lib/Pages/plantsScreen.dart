import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/AppDrawer.dart';
import 'package:abed_gp2/Widgets/PlantCard.dart';
import 'package:abed_gp2/Widgets/navItemData.dart';
import 'package:abed_gp2/Widgets/plantStatus.dart';
import 'package:abed_gp2/services/raspberry_api.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PlantsScreen extends StatefulWidget {
  const PlantsScreen({super.key});

  @override
  State<PlantsScreen> createState() => _PlantsScreenState();
}

class _PlantsScreenState extends State<PlantsScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  bool _loadingScan = false;
  String? _scanError;
  RaspberryScanResult? _scanResult;

  static const List<PlantCardData> _basePlants = [
    PlantCardData(
      name: 'Apple Tree 1',
      species: 'Malus domestica',
      zone: 'Zone D – Apples',
      fruit: 'apple',
      status: PlantStatus.healthy,
    ),
    PlantCardData(
      name: 'Basil Cluster',
      species: 'Ocimum basilicum',
      zone: 'Zone C – Herbs',
      fruit: 'basil',
      status: PlantStatus.healthy,
    ),
    PlantCardData(
      name: 'Bell Pepper 1',
      species: 'Capsicum annuum',
      zone: 'Zone B – Peppers',
      fruit: 'pepper',
      status: PlantStatus.healthy,
    ),
    PlantCardData(
      name: 'Bell Pepper 2',
      species: 'Capsicum annuum',
      zone: 'Zone B – Peppers',
      fruit: 'pepper',
      status: PlantStatus.underwatered,
    ),
    PlantCardData(
      name: 'Rosemary Bush',
      species: 'Salvia rosmarinus',
      zone: 'Zone C – Herbs',
      fruit: 'rosemary',
      status: PlantStatus.overwatered,
    ),
    PlantCardData(
      name: 'Tomato Plant 1',
      species: 'Solanum lycopersicum',
      zone: 'Zone A – Tomatoes',
      fruit: 'tomato',
      status: PlantStatus.healthy,
    ),
    PlantCardData(
      name: 'Tomato Plant 2',
      species: 'Solanum lycopersicum',
      zone: 'Zone A – Tomatoes',
      fruit: 'tomato',
      status: PlantStatus.stressed,
    ),
  ];

  List<PlantCardData> get _plants {
    final scan = _scanResult;

    if (scan == null || scan.ready != true || scan.fruit.isEmpty) {
      return _basePlants;
    }

    return _basePlants.map((plant) {
      if (plant.fruit.toLowerCase() != scan.fruit.toLowerCase()) {
        return plant;
      }

      return PlantCardData(
        name: plant.name,
        species: plant.species,
        zone: plant.zone,
        fruit: plant.fruit,
        status: _statusFromDisease(scan.disease),
      );
    }).toList();
  }

  List<PlantCardData> get _filtered => _plants
      .where((p) =>
          p.name.toLowerCase().contains(_query.toLowerCase()) ||
          p.species.toLowerCase().contains(_query.toLowerCase()) ||
          p.zone.toLowerCase().contains(_query.toLowerCase()) ||
          p.fruit.toLowerCase().contains(_query.toLowerCase()))
      .toList();

  PlantStatus _statusFromDisease(String disease) {
    final value = disease.toLowerCase();

    if (value.contains('healthy') || value.contains('healty')) {
      return PlantStatus.healthy;
    }

    return PlantStatus.diseased;
  }

  @override
  void initState() {
    super.initState();
    _loadScanResult();
  }

  Future<void> _loadScanResult() async {
    setState(() {
      _loadingScan = true;
      _scanError = null;
    });

    try {
      final result = await RaspberryApi.getResult();
      if (!mounted) return;
      setState(() {
        _scanResult = result;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _scanError = 'Cannot connect to Raspberry API';
      });
    } finally {
      if (!mounted) return;
      setState(() {
        _loadingScan = false;
      });
    }
  }

  Future<void> _resetScan() async {
    try {
      await RaspberryApi.resetScan();
      await _loadScanResult();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _scanError = 'Cannot reset Raspberry scan';
      });
    }
  }

  void _showPlantInfo(PlantCardData plant) {
    final scan = _scanResult;

    if (scan == null ||
        scan.ready != true ||
        scan.info.isEmpty ||
        scan.fruit.toLowerCase() != plant.fruit.toLowerCase()) {
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${plant.name} - ${scan.disease}'),
        content: SingleChildScrollView(child: Text(scan.info)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      drawer: AppDrawer(
        appName: 'AgriBot OS',
        headerIcon: Icons.smart_toy_outlined,
        items: appNavItems,
        activeRoute: '/plants',
        onItemTap: (item) => Navigator.pushReplacementNamed(context, item.routeName),
      ),
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: AppColors.textDark),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: Text('Plants Repository',
            style: GoogleFonts.fraunces(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: AppColors.textDark)),
        actions: [
          IconButton(
            tooltip: 'Refresh Raspberry result',
            icon: _loadingScan
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh_rounded, color: AppColors.textDark),
            onPressed: _loadingScan ? null : _loadScanResult,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _query = v),
              style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.textDark),
              decoration: InputDecoration(
                hintText: 'Search by name, species or zone…',
                hintStyle: GoogleFonts.dmSans(
                    fontSize: 13, color: AppColors.textMuted),
                prefixIcon: const Icon(Icons.search_rounded,
                    size: 18, color: AppColors.textMuted),
                filled: true,
                fillColor: AppColors.cardWhite,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        const BorderSide(color: AppColors.border, width: 0.5)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        const BorderSide(color: AppColors.border, width: 0.5)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(
                        color: AppColors.borderFocus, width: 1.5)),
              ),
            ),
          ),

          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.85,
              ),
              itemCount: _filtered.length,
              itemBuilder: (_, i) {
                final plant = _filtered[i];
                return PlantCard(
                  data: plant,
                  onTap: () => _showPlantInfo(plant),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ScanResultBanner extends StatelessWidget {
  final RaspberryScanResult? scanResult;
  final String? error;
  final bool isLoading;
  final VoidCallback onRefresh;
  final VoidCallback onReset;
  final VoidCallback onShowInfo;

  const _ScanResultBanner({
    required this.scanResult,
    required this.error,
    required this.isLoading,
    required this.onRefresh,
    required this.onReset,
    required this.onShowInfo,
  });

  @override
  Widget build(BuildContext context) {
    final scan = scanResult;

    String title = 'Raspberry scan result';
    String subtitle = 'Press refresh to read the latest scan.';

    if (isLoading) {
      subtitle = 'Loading result from Raspberry Pi...';
    } else if (error != null) {
      subtitle = error!;
    } else if (scan != null && scan.ready) {
      title = '${scan.fruit.toUpperCase()} • ${scan.disease}';
      subtitle = 'Confidence: ${scan.confidence.toStringAsFixed(1)}%';
    } else if (scan != null) {
      subtitle = 'No plant result is ready yet.';
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.memory_rounded, size: 18, color: AppColors.textDark),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textDark,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.textMuted),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              TextButton.icon(
                onPressed: isLoading ? null : onRefresh,
                icon: const Icon(Icons.refresh_rounded, size: 16),
                label: const Text('Refresh'),
              ),
              TextButton.icon(
                onPressed: isLoading ? null : onReset,
                icon: const Icon(Icons.restart_alt_rounded, size: 16),
                label: const Text('Reset'),
              ),
              const Spacer(),
              if (scan != null && scan.info.isNotEmpty)
                TextButton(
                  onPressed: onShowInfo,
                  child: const Text('Info'),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
