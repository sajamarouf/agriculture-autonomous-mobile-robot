// ignore_for_file: curly_braces_in_flow_control_structures, use_build_context_synchronously

import 'package:abed_gp2/Routes/route1_string.dart';
import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/authTextFeild.dart';
import 'package:abed_gp2/Widgets/bottomLink.dart';
import 'package:abed_gp2/Widgets/logoHeader.dart';
import 'package:abed_gp2/Widgets/orDivider.dart';
import 'package:abed_gp2/Widgets/primaryButton.dart';
import 'package:abed_gp2/Widgets/socialButton.dart';
import 'package:abed_gp2/Widgets/tapToggle.dart';
import 'package:abed_gp2/imageString.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SignInScreen extends StatefulWidget {
  final VoidCallback? onGoToSignUp;

  const SignInScreen({super.key, this.onGoToSignUp});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _obscure = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _handleSignIn() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailCtrl.text.trim(),
        password: _passwordCtrl.text.trim(),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Sign in successful")),
      );

 Navigator.pushReplacementNamed(
  context,
  Route1String.dashboardScreen,
);

    } on FirebaseAuthException catch (e) {
      String message;

      if (e.code == 'user-not-found') {
        message = 'No user found for that email';
      } else if (e.code == 'wrong-password') {
        message = 'Wrong password';
      } else if (e.code == 'invalid-email') {
        message = 'Invalid email address';
      } else {
        message = e.message ?? 'Login failed';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                LogoHeader(
                  imagePath: Imagestringpng.logo,
                  appName: 'PlantBot',
                  tagline: 'Smart Garden Assistant',
                ),
                const SizedBox(height: 20),

                TabToggle(
                  activeIndex: 0,
                  labels: const ['Sign In', 'Sign Up'],
                  onTap: (i) {
                    if (i == 1) {
                      Navigator.pushReplacementNamed(
                        context,
                        Route1String.signUpScreen,
                      );
                    }
                  },
                ),
                const SizedBox(height: 24),

                Text(
                  'Welcome back 🌱',
                  style: GoogleFonts.fraunces(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textDark,
                  ),
                ),
                const SizedBox(height: 4),

                Text(
                  'Sign in to your garden',
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    color: AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 24),

                AuthTextField(
                  controller: _emailCtrl,
                  label: 'Email',
                  hint: 'you@example.com',
                  prefixIcon: Icons.mail_outline_rounded,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) =>
                      v == null || !v.contains('@') ? 'Enter a valid email' : null,
                ),
                const SizedBox(height: 16),

                AuthTextField(
                  controller: _passwordCtrl,
                  label: 'Password',
                  hint: '••••••••',
                  prefixIcon: Icons.lock_outline_rounded,
                  obscureText: _obscure,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppColors.iconColor,
                      size: 20,
                    ),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                  validator: (v) =>
                      v == null || v.length < 6 ? 'Password too short' : null,
                ),
                const SizedBox(height: 8),

                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      
                    },
                    child: Text(
                      'Forgot password?',
                      style: GoogleFonts.dmSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                PrimaryButton(
                  label: 'Sign In',
                  icon: Icons.login_rounded,
                  isLoading: _isLoading,
                  onPressed: _handleSignIn,
                ),
                const SizedBox(height: 20),

                OrDivider(label: 'or continue with'),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: SocialButton(
                        label: 'Google',
                        svgAsset: 'assets/icons/google.svg',
                        onPressed: () {
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SocialButton(
                        label: 'Apple',
                        svgAsset: 'assets/icons/apple.svg',
                        onPressed: () {
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                BottomLink(
                  prefix: "Don't have an account? ",
                  action: 'Sign Up',
                  onTap: () {
                    Navigator.pushReplacementNamed(
                      context,
                      Route1String.signUpScreen,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}