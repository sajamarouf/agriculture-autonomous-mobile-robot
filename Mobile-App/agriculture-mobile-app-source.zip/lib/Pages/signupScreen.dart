// ignore_for_file: curly_braces_in_flow_control_structures, use_build_context_synchronously

import 'package:abed_gp2/Routes/route1_string.dart';
import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/authTextFeild.dart';
import 'package:abed_gp2/Widgets/bottomLink.dart';
import 'package:abed_gp2/Widgets/logoHeader.dart';
import 'package:abed_gp2/Widgets/orDivider.dart';
import 'package:abed_gp2/Widgets/passwordStrengthBar.dart';
import 'package:abed_gp2/Widgets/primaryButton.dart';
import 'package:abed_gp2/Widgets/socialButton.dart';
import 'package:abed_gp2/Widgets/tapToggle.dart';
import 'package:abed_gp2/imageString.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SignUpScreen extends StatefulWidget {
  final VoidCallback? onGoToSignIn;

  const SignUpScreen({super.key, this.onGoToSignIn});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstCtrl = TextEditingController();
  final _lastCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _obscure = true;
  bool _isLoading = false;

  PasswordStrength get _strength =>
      PasswordStrengthExt.fromPassword(_passwordCtrl.text);

  @override
  void dispose() {
    _firstCtrl.dispose();
    _lastCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _handleSignUp() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailCtrl.text.trim(),
        password: _passwordCtrl.text.trim(),
      );

      await FirebaseAuth.instance.currentUser?.updateDisplayName(
        '${_firstCtrl.text.trim()} ${_lastCtrl.text.trim()}',
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Account created successfully')),
      );

      Navigator.pushReplacementNamed(context, Route1String.dashboardScreen);
    } on FirebaseAuthException catch (e) {
      String message;

      if (e.code == 'email-already-in-use') {
        message = 'This email is already used';
      } else if (e.code == 'weak-password') {
        message = 'Password is too weak';
      } else if (e.code == 'invalid-email') {
        message = 'Invalid email address';
      } else {
        message = e.message ?? 'Sign up failed';
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                LogoHeader(
                  imagePath: Imagestringpng.logo,
                  appName: 'PlantBot',
                  tagline: 'Smart Garden Assistant',
                ),
                const SizedBox(height: 20),

                TabToggle(
                  activeIndex: 1,
                  labels: const ['Sign In', 'Sign Up'],
                  onTap: (i) {
                    if (i == 0) {
                      Navigator.pushReplacementNamed(
                        context,
                        Route1String.signInScreen,
                      );
                    }
                  },
                ),
                const SizedBox(height: 24),

                Text(
                  'Create account 🌿',
                  style: GoogleFonts.fraunces(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textDark,
                  ),
                ),
                const SizedBox(height: 4),

                Text(
                  'Start growing smarter today',
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    color: AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 24),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: AuthTextField(
                        controller: _firstCtrl,
                        label: 'First name',
                        hint: 'Alex',
                        prefixIcon: Icons.person_outline_rounded,
                        validator: (v) =>
                            v == null || v.isEmpty ? 'Required' : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: AuthTextField(
                        controller: _lastCtrl,
                        label: 'Last name',
                        hint: 'Smith',
                        prefixIcon: Icons.person_outline_rounded,
                        validator: (v) =>
                            v == null || v.isEmpty ? 'Required' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                AuthTextField(
                  controller: _emailCtrl,
                  label: 'Email',
                  hint: 'you@example.com',
                  prefixIcon: Icons.mail_outline_rounded,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) => v == null || !v.contains('@')
                      ? 'Enter a valid email'
                      : null,
                ),
                const SizedBox(height: 16),

                ValueListenableBuilder<TextEditingValue>(
                  valueListenable: _passwordCtrl,
                  builder: (_, __, ___) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AuthTextField(
                        controller: _passwordCtrl,
                        label: 'Password',
                        hint: 'Create a strong password',
                        prefixIcon: Icons.lock_outline_rounded,
                        obscureText: _obscure,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            color: AppColors.iconColor,
                            size: 20,
                          ),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                        validator: (v) => v == null || v.length < 6
                            ? 'At least 6 characters'
                            : null,
                      ),
                      const SizedBox(height: 8),
                      PasswordStrengthBar(strength: _strength),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                PrimaryButton(
                  label: 'Create Account',
                  icon: Icons.eco_rounded,
                  isLoading: _isLoading,
                  onPressed: _handleSignUp,
                ),
                const SizedBox(height: 20),

                OrDivider(label: 'or sign up with'),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: SocialButton(
                        label: 'Google',
                        svgAsset: 'assets/icons/google.svg',
                        onPressed: () {
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SocialButton(
                        label: 'Apple',
                        svgAsset: 'assets/icons/apple.svg',
                        onPressed: () {
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                BottomLink(
                  prefix: 'Already have an account? ',
                  action: 'Sign In',
                  onTap: () {
                    Navigator.pushReplacementNamed(
                      context,
                      Route1String.signInScreen,
                    );
                  },
                ),
                const SizedBox(height: 14),

                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      color: AppColors.textMuted,
                    ),
                    children: const [
                      TextSpan(text: 'By signing up you agree to our '),
                      TextSpan(
                        text: 'Terms',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      TextSpan(text: ' and '),
                      TextSpan(
                        text: 'Privacy Policy',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
