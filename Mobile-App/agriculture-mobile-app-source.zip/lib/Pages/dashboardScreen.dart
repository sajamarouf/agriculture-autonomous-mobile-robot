import 'package:abed_gp2/Widgets/AppColors.dart';
import 'package:abed_gp2/Widgets/AppDrawer.dart';
import 'package:abed_gp2/Widgets/navItemData.dart';
import 'package:abed_gp2/Widgets/robotTelemetryCard.dart';
import 'package:abed_gp2/Widgets/statCardRow.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _activeRoute = '/dashboard';

  void _onNavTap(NavItemData item) {
  if (item.routeName == _activeRoute) return;

  Navigator.pushReplacementNamed(context, item.routeName);
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,

      drawer: AppDrawer(
        appName: 'AgriBot OS',
        headerIcon: Icons.smart_toy_outlined,
        items: appNavItems,
        activeRoute: _activeRoute,
        onItemTap: _onNavTap,
      ),

      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu_rounded, color: AppColors.textDark),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: Text('Dashboard',
            style: GoogleFonts.fraunces(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: AppColors.textDark)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.cardWhite,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border, width: 0.5),
            ),
            child: Row(children: [
              Container(
                width: 8, height: 8,
                decoration: const BoxDecoration(
                    color: AppColors.primary, shape: BoxShape.circle),
              ),
              const SizedBox(width: 6),
              Text('Robot Online',
                  style: GoogleFonts.dmSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textDark)),
            ]),
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Real-time overview of agricultural operations',
                style: GoogleFonts.dmSans(
                    fontSize: 12, color: AppColors.textMuted)),
            const SizedBox(height: 20),

            StatCardsRow(
              cards: const [
                StatCardData(
                  title: 'Total Plants Monitored',
                  value: '6',
                  icon: Icons.eco_outlined,
                  subtitle: '3 healthy · 1 stressed',
                ),
                StatCardData(
                  title: 'Avg Soil Moisture',
                  value: '59.9%',
                  icon: Icons.water_drop_outlined,
                  progress: 0.599,
                  progressColor: AppColors.primary,
                ),
                StatCardData(
                  title: 'Irrigation Today',
                  value: '0.0L',
                  icon: Icons.show_chart_rounded,
                  subtitle: 'Water dispensed across all zones',
                ),
                StatCardData(
                  title: 'Active Alerts',
                  value: '2',
                  icon: Icons.warning_amber_rounded,
                  iconColor: Colors.redAccent,
                  valueColor: Colors.redAccent,
                  subtitle: 'Require immediate attention',
                  subtitleColor: Colors.redAccent,
                ),
              ],
            ),
            const SizedBox(height: 20),

            RobotTelemetryCard(
              currentMode: 'Monitoring',
              location: 'Zone A - Tomatoes',
              batteryLevel: 0.78,
              waterTankLevel: 0.65,
              lastSeen: '23:48:44 PM',
            ),
          ],
        ),
      ),
    );
  }
}