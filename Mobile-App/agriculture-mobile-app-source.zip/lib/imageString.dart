class Imagestringpng {
  static const String logo = 'assets/png/robot_logo.png';
}