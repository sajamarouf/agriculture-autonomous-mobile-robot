package com.example.abed_gp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
